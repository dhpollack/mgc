# Datasets

## Instructions

1. Mount data drive

```sh
sudo mount -o defaults /dev/sdb1 /mnt/data
```

## Audioset - Google Research Dataset
